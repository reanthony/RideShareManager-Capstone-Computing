

var express = require('express'); 
var router = express.Router();

router.get("/", function(req, res, next) {
    res.json({
        name:"unknown name", 
        latitude:33.20251175430355, 
        longitude:-87.55384535275205
    });  
}); 


module.exports = router;
