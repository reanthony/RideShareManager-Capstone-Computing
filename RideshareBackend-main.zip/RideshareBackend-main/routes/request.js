var express = require('express'); 
var router = express.Router(); 

var pickupQueue = []; 


/* get users listing */
router.get('/', function(req, res, next) {
    res.send("you want a ride?"); 
}); 

// posts a rider to the queue
router.post('/pickup', function(req, res) {
    var rider = req.body; 
    console.log(rider); 
    pickupQueue.push(rider); 
    res.send("rider Added!");  
    console.log(pickupQueue); 
}); 

router.get('/scoop', function(req, res){
    var rider = pickupQueue.pop(); 
    console.log("scooping!"); 
    res.json(rider); 
}); 


module.exports = router; 

