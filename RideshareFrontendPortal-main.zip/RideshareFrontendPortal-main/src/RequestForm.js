import React, { Component } from "react"; 

const axios = require('axios'); 

class RequestForm extends Component {
    // constructor // 
    constructor(props) {
        super(props); 
        this.state = { name: "" }; 
        
        // Binding methods allows them to use the "this" keyword in their body 
        this.handleTextChange = this.handleTextChange.bind(this); 
        this.postMessage = this.postMessage.bind(this); 
        this.sendRideRequest = this.sendRideRequest.bind(this); 
    }
    
    // Called after getCurrentPosition() call if the location is available
    async sendRideRequest(pos) {
        var url = "http://localhost:9000/request/pickup";
        var crd = pos.coords; 
        console.log(crd); 
        var newRider = {
            name: this.state.name, 
            latitude: crd.latitude, 
            longitude: crd.longitude
        };
        console.log("printing rider"); 
        console.log(newRider);
        const response = await axios.post(url, newRider); 
        console.log(response); 
    }  
    
    // Called when the users clickes the button
    async postMessage(){
        console.log("posting message!");
        navigator.geolocation.getCurrentPosition(
            this.sendRideRequest, 
            function(err) {
                console.warn("unable to get location"); 
            }, {timeout: 5000}); 
    }
    
    // called when the user enters text into the text box
    handleTextChange(event) {
        this.setState({name: event.target.value}); 
    }

    render() {
        return(
                <header className="Button"> 
                    <label>
                        Name: 
                        <input type="text" value={this.state.name} onChange={this.handleTextChange} />
                    </label>
                    <button onClick={this.postMessage}>Order my ride!</button>
                </header>
        );  
    }
    
}

export default RequestForm; 
