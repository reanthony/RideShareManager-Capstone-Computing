import React, { Component  } from "react"; 
import logo from './logo.svg';
import './App.css';

import RequestForm from './RequestForm'; 

const axios = require('axios'); 


class App extends Component {
    
    // constructor 
    constructor(props) {
        super(props); 
        this.state = { value: "" }; 
    }
    

    // store data to the server 
    // fetch the data from the server and store the response to the current state //   
    async callAPI() {
        // localhost:9000 for debug, heroku for prod 
        var url = "http://localhost:9000/testAPI";  
        //var url = "https://ridesharebackend.herokuapp.com/testAPI"
        const response = await axios.get(url); 
        this.setState({apiResponse: "there are " + response.data + "drivers available"});  
    }

    componentDidMount() {
        //this.callAPI();
    }

    // this function is called once each frame to render the frame
    render() {
        return (
            <div className="App">
                <header className="riderqueue">
                    <p>this.state.apiResponse</p> 
                </header>
                <header className="App-header">
                    <img src={logo} className="App-logo" alt="logo" />
                    <p> { "click the button to order a ride" } </p>
                    <RequestForm /> 
                </header>
            </div>
        );
    }
}

 
export default App;


 

